/**
 * \file
 * Copyright 2016 Microsoft
 * Licensed under the MIT license. See LICENSE file in the project root for full license information.
 */
#ifndef _MONO_METADATA_W32FILE_INTERNALS_H_
#define _MONO_METADATA_W32FILE_INTERNALS_H_

#include <config.h>
#include <glib.h>

#endif /* _MONO_METADATA_W32FILE_INTERNALS_H_ */
